﻿namespace queueSysHW
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtLambda = new System.Windows.Forms.TextBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.txtLq = new System.Windows.Forms.TextBox();
            this.txtLs = new System.Windows.Forms.TextBox();
            this.txtRho = new System.Windows.Forms.TextBox();
            this.txtMho = new System.Windows.Forms.TextBox();
            this.txtP0 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.txtWq = new System.Windows.Forms.TextBox();
            this.txtWs = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.txtPn = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtLambda
            // 
            this.txtLambda.BackColor = System.Drawing.Color.PeachPuff;
            this.txtLambda.Font = new System.Drawing.Font("Tahoma", 12F);
            this.txtLambda.Location = new System.Drawing.Point(117, 43);
            this.txtLambda.Name = "txtLambda";
            this.txtLambda.Size = new System.Drawing.Size(157, 32);
            this.txtLambda.TabIndex = 0;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(-6, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1184, 528);
            this.tabControl1.TabIndex = 1;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.button4);
            this.tabPage1.Controls.Add(this.label12);
            this.tabPage1.Controls.Add(this.txtPn);
            this.tabPage1.Controls.Add(this.label11);
            this.tabPage1.Controls.Add(this.label10);
            this.tabPage1.Controls.Add(this.label9);
            this.tabPage1.Controls.Add(this.label8);
            this.tabPage1.Controls.Add(this.label7);
            this.tabPage1.Controls.Add(this.label6);
            this.tabPage1.Controls.Add(this.label5);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.txtWs);
            this.tabPage1.Controls.Add(this.txtWq);
            this.tabPage1.Controls.Add(this.button3);
            this.tabPage1.Controls.Add(this.button2);
            this.tabPage1.Controls.Add(this.button1);
            this.tabPage1.Controls.Add(this.txtP0);
            this.tabPage1.Controls.Add(this.txtMho);
            this.tabPage1.Controls.Add(this.txtRho);
            this.tabPage1.Controls.Add(this.txtLs);
            this.tabPage1.Controls.Add(this.txtLq);
            this.tabPage1.Controls.Add(this.txtLambda);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1176, 499);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "tabPage1";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabPage2
            // 
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(192, 71);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "tabPage2";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // txtLq
            // 
            this.txtLq.BackColor = System.Drawing.Color.PeachPuff;
            this.txtLq.Font = new System.Drawing.Font("Tahoma", 12F);
            this.txtLq.Location = new System.Drawing.Point(126, 330);
            this.txtLq.Name = "txtLq";
            this.txtLq.Size = new System.Drawing.Size(157, 32);
            this.txtLq.TabIndex = 4;
            // 
            // txtLs
            // 
            this.txtLs.BackColor = System.Drawing.Color.PeachPuff;
            this.txtLs.Font = new System.Drawing.Font("Tahoma", 12F);
            this.txtLs.Location = new System.Drawing.Point(126, 275);
            this.txtLs.Name = "txtLs";
            this.txtLs.Size = new System.Drawing.Size(157, 32);
            this.txtLs.TabIndex = 5;
            // 
            // txtRho
            // 
            this.txtRho.BackColor = System.Drawing.Color.PeachPuff;
            this.txtRho.Font = new System.Drawing.Font("Tahoma", 12F);
            this.txtRho.Location = new System.Drawing.Point(187, 161);
            this.txtRho.Name = "txtRho";
            this.txtRho.Size = new System.Drawing.Size(157, 32);
            this.txtRho.TabIndex = 6;
            // 
            // txtMho
            // 
            this.txtMho.BackColor = System.Drawing.Color.PeachPuff;
            this.txtMho.Font = new System.Drawing.Font("Tahoma", 12F);
            this.txtMho.Location = new System.Drawing.Point(117, 108);
            this.txtMho.Name = "txtMho";
            this.txtMho.Size = new System.Drawing.Size(157, 32);
            this.txtMho.TabIndex = 7;
            // 
            // txtP0
            // 
            this.txtP0.BackColor = System.Drawing.Color.PeachPuff;
            this.txtP0.Font = new System.Drawing.Font("Tahoma", 12F);
            this.txtP0.Location = new System.Drawing.Point(510, 55);
            this.txtP0.Name = "txtP0";
            this.txtP0.Size = new System.Drawing.Size(157, 32);
            this.txtP0.TabIndex = 8;
            this.txtP0.TextChanged += new System.EventHandler(this.txtP0_TextChanged);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.SlateGray;
            this.button1.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold);
            this.button1.Location = new System.Drawing.Point(59, 163);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(122, 32);
            this.button1.TabIndex = 9;
            this.button1.Text = "CslcRho";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.SlateGray;
            this.button2.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold);
            this.button2.Location = new System.Drawing.Point(126, 214);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(242, 32);
            this.button2.TabIndex = 10;
            this.button2.Text = "Calc Performance";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.SlateGray;
            this.button3.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold);
            this.button3.Location = new System.Drawing.Point(545, 116);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(122, 32);
            this.button3.TabIndex = 11;
            this.button3.Text = "CalcP0";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // txtWq
            // 
            this.txtWq.BackColor = System.Drawing.Color.PeachPuff;
            this.txtWq.Font = new System.Drawing.Font("Tahoma", 12F);
            this.txtWq.Location = new System.Drawing.Point(126, 429);
            this.txtWq.Name = "txtWq";
            this.txtWq.Size = new System.Drawing.Size(157, 32);
            this.txtWq.TabIndex = 12;
            // 
            // txtWs
            // 
            this.txtWs.BackColor = System.Drawing.Color.PeachPuff;
            this.txtWs.Font = new System.Drawing.Font("Tahoma", 12F);
            this.txtWs.Location = new System.Drawing.Point(126, 379);
            this.txtWs.Name = "txtWs";
            this.txtWs.Size = new System.Drawing.Size(157, 32);
            this.txtWs.TabIndex = 13;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(42, 17);
            this.label1.TabIndex = 14;
            this.label1.Text = "label1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold);
            this.label2.Location = new System.Drawing.Point(346, 46);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(72, 24);
            this.label2.TabIndex = 15;
            this.label2.Text = "lamda";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold);
            this.label3.Location = new System.Drawing.Point(346, 333);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(34, 24);
            this.label3.TabIndex = 16;
            this.label3.Text = "Lq";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold);
            this.label4.Location = new System.Drawing.Point(362, 275);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(34, 24);
            this.label4.TabIndex = 17;
            this.label4.Text = "LS";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold);
            this.label5.Location = new System.Drawing.Point(346, 275);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(0, 24);
            this.label5.TabIndex = 18;
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold);
            this.label6.Location = new System.Drawing.Point(390, 171);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(44, 24);
            this.label6.TabIndex = 19;
            this.label6.Text = "rho";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold);
            this.label7.Location = new System.Drawing.Point(346, 116);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(54, 24);
            this.label7.TabIndex = 20;
            this.label7.Text = "mho";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold);
            this.label8.Location = new System.Drawing.Point(346, 387);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(41, 24);
            this.label8.TabIndex = 21;
            this.label8.Text = "Ws";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold);
            this.label9.Location = new System.Drawing.Point(346, 379);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(0, 24);
            this.label9.TabIndex = 22;
            this.label9.Click += new System.EventHandler(this.label9_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold);
            this.label10.Location = new System.Drawing.Point(336, 432);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(44, 24);
            this.label10.TabIndex = 23;
            this.label10.Text = "Wq";
            this.label10.Click += new System.EventHandler(this.label10_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold);
            this.label11.Location = new System.Drawing.Point(695, 58);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(36, 24);
            this.label11.TabIndex = 24;
            this.label11.Text = "P0";
            // 
            // txtPn
            // 
            this.txtPn.BackColor = System.Drawing.Color.PeachPuff;
            this.txtPn.Font = new System.Drawing.Font("Tahoma", 12F);
            this.txtPn.Location = new System.Drawing.Point(510, 184);
            this.txtPn.Name = "txtPn";
            this.txtPn.Size = new System.Drawing.Size(157, 32);
            this.txtPn.TabIndex = 25;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold);
            this.label12.Location = new System.Drawing.Point(695, 187);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(36, 24);
            this.label12.TabIndex = 26;
            this.label12.Text = "Pn";
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.SlateGray;
            this.button4.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold);
            this.button4.Location = new System.Drawing.Point(545, 232);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(122, 32);
            this.button4.TabIndex = 27;
            this.button4.Text = "CalcPn";
            this.button4.UseVisualStyleBackColor = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1180, 538);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox txtLambda;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox txtP0;
        private System.Windows.Forms.TextBox txtMho;
        private System.Windows.Forms.TextBox txtRho;
        private System.Windows.Forms.TextBox txtLs;
        private System.Windows.Forms.TextBox txtLq;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TextBox txtWs;
        private System.Windows.Forms.TextBox txtWq;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtPn;
    }
}

