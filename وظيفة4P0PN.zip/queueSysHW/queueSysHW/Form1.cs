﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace queueSysHW
{
    public partial class Form1 : Form
    {
        private double rho = -1;
        public Form1()
        {
            InitializeComponent();
            SetDefulatProp();
        }
        private void SetDefulatProp()
        {
            txtLs.ReadOnly = true;
            txtLq.ReadOnly = true;
            txtWs.ReadOnly = true;
            txtWq.ReadOnly = true;
            txtRho.ReadOnly = true;
            txtP0.ReadOnly = true;
            txtPn.ReadOnly = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                double lambda = double.Parse(txtLambda.Text);
                double mu = double.Parse(txtMho.Text);
                if (mu == 0)
                {

                    throw new DivideByZeroException("لا يمكن ان تكون ميو صفر");
                }
                if (mu <= lambda)
                {
                    throw new Exception("لا يمكن ان تكون متساوية القيم");
                }
                rho = lambda / mu;
                txtRho.Text = rho.ToString("F2");
                if (rho < 0.5)
                {
                    txtRho.BackColor = Color.LightGreen;
                }
                else if (rho < 0.8)
                {
                    txtRho.BackColor = Color.Orange;
                }
                else
                {
                    txtRho.BackColor = Color.Red;
                }
            }
            catch (Exception ex)
            {
                if (ex is FormatException)
                    MessageBox.Show("تأكد من إدخال قيم صحيحة للمدخلات.");
                else if (ex is DivideByZeroException)
                {
                    txtMho.BackColor = Color.Red;
                    MessageBox.Show(ex.Message);
                }
                else
                {
                    MessageBox.Show(ex.Message);
                }
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                double lambda = double.Parse(txtLambda.Text);
                double mu = double.Parse(txtMho.Text);

                if (lambda >= mu)
                {
                    MessageBox.Show("النظام غير مستقر. تأكد من أن معدل الوصول أقل من معدل الخدمة.");
                    HighlightTextBox(txtLs, Color.Red);
                    return;
                }

                double rho = lambda / mu;

                double L = rho / (1 - rho);
                double Lq = Math.Pow(rho, 2) / (1 - rho);
                double W = 1 / (mu - lambda);
                double Wq = rho / (mu - lambda);

                txtLs.Text = L.ToString("F2");//F2 to show only two number after point 
                txtLq.Text = Lq.ToString("F2");
                txtWs.Text = W.ToString("F2");
                txtWq.Text = Wq.ToString("F2");

            }
            catch (FormatException)
            {
                MessageBox.Show("تأكد من إدخال قيم صحيحة للمدخلات.");
            }
        }

        private void HighlightTextBox(TextBox txtLs, Color red)
        {
            throw new NotImplementedException();
        }

        private void button3_Click(object sender, EventArgs e)
        {try { 
            if (rho < 0)
            {
                    throw new Exception("the rho negative");
            }


            txtP0.Text = (1 - rho).ToString();
                int n;
                if (int.TryParse(txtPn.Text, out n) && n >= 0)
                {
                    double Pn = Math.Pow(rho, n) * (1 - rho);
                    txtPn.Text = Pn.ToString("F2");
                }
                else
                {
                    MessageBox.Show("تأكد من إدخال قيمة صحيحة لـ n.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtP0_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }
    }
}
