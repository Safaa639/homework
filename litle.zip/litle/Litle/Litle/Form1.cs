﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Litle
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            txtLq.ReadOnly = true;
            txtLs.ReadOnly = true;
            txtrouh.ReadOnly = true;
            txtLResult.ReadOnly = true;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e) //lamda
        {


        }

        private void textBox6_TextChanged(object sender, EventArgs e) //WQ
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e) //Ws
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e) //Lq
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e) //Ls
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        { //قراءة المدخلات
            try {
                double lamda = Convert.ToDouble(txtLa.Text); //txt.Text قيمة معروفة بس باخد قيمتا
                double wq = Convert.ToDouble(txtWq.Text);
                double ws = Convert.ToDouble(txtWs.Text);
                double Lq = lamda * wq;
                double Ls = lamda * ws;
                txtLs.Text = Ls.ToString(); //اذا كان العنصر عاليسار خود تكست حطلي فيو قيمةtxt.Text
                txtLq.Text = Lq.ToString();
            }
            catch (Exception ex)
            {
                if (ex is FormatException)
                    MessageBox.Show("تأكد من إدخال قيم صحيحة للمدخلات.");
                else
                {
                    MessageBox.Show(ex.Message);
                }


            } }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                // قراءة المدخلات
                double mu = double.Parse(txtMu.Text);
                double lamda = Convert.ToDouble(txtLa.Text);

                // التحقق من الشروط
                if (mu == 0)
                {
                    throw new ArgumentException("mu يجب أن لا يكون مساويًا للصفر.");
                }

                double rouh = lamda / mu;

                if (rouh < 1 || rouh >= 0)
                {
                    throw new ArgumentException("rouh يجب أن يكون أكبر من أو يساوي صفر وأقل من واحد.");
                }

                txtrouh.Text = rouh.ToString();
                MessageBox.Show($"القيمة المحسوبة لـ rouh هي: {rouh}");
            }
            catch (FormatException)
            {
                MessageBox.Show("يرجى التأكد من إدخال قيم صحيحة (أرقام فقط).");
            }
            catch (ArgumentException ex)
            {
                MessageBox.Show(ex.Message);
            }
          
            catch (Exception ex)
            {
                MessageBox.Show("حدث خطأ غير متوقع: " + ex.Message);
            }
        
    }

        private void txtrouh_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnCalcLatel_Click(object sender, EventArgs e)
        {
            try
            {
                double lamda = Convert.ToDouble(txtLa.Text);
                double W = Convert.ToDouble(txtw.Text);
                
                double L = lamda * W;
                
                txtLResult.Text = L.ToString();
            }
            catch (FormatException)
            {
                MessageBox.Show("يرجى التأكد من إدخال قيم صحيحة (أرقام فقط) لمعدل الوصول ووقت الانتظار.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("حدث خطأ غير متوقع: " + ex.Message);
            }
        }

        private void txtw_TextChanged(object sender, EventArgs e)
        {

        }
    }
    
}
