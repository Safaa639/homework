﻿namespace queueSysHW
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtLambda = new System.Windows.Forms.TextBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.txtN = new System.Windows.Forms.TextBox();
            this.button4 = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.txtPn = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtWs = new System.Windows.Forms.TextBox();
            this.txtWq = new System.Windows.Forms.TextBox();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.txtP0 = new System.Windows.Forms.TextBox();
            this.txtMho = new System.Windows.Forms.TextBox();
            this.txtRho = new System.Windows.Forms.TextBox();
            this.txtLs = new System.Windows.Forms.TextBox();
            this.txtLq = new System.Windows.Forms.TextBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.lblMMSReultP0 = new System.Windows.Forms.Label();
            this.calcMMSP0 = new System.Windows.Forms.Button();
            this.txtMMSP0 = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.txtMMSServicesCount = new System.Windows.Forms.TextBox();
            this.txtMMSmho = new System.Windows.Forms.TextBox();
            this.txtMMSLambda = new System.Windows.Forms.TextBox();
            this.CalcPn = new System.Windows.Forms.Button();
            this.textn = new System.Windows.Forms.TextBox();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtLambda
            // 
            this.txtLambda.BackColor = System.Drawing.Color.PeachPuff;
            this.txtLambda.Font = new System.Drawing.Font("Tahoma", 12F);
            this.txtLambda.Location = new System.Drawing.Point(117, 43);
            this.txtLambda.Name = "txtLambda";
            this.txtLambda.Size = new System.Drawing.Size(157, 32);
            this.txtLambda.TabIndex = 0;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(-6, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1184, 528);
            this.tabControl1.TabIndex = 1;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.txtN);
            this.tabPage1.Controls.Add(this.button4);
            this.tabPage1.Controls.Add(this.label12);
            this.tabPage1.Controls.Add(this.txtPn);
            this.tabPage1.Controls.Add(this.label11);
            this.tabPage1.Controls.Add(this.label10);
            this.tabPage1.Controls.Add(this.label9);
            this.tabPage1.Controls.Add(this.label8);
            this.tabPage1.Controls.Add(this.label7);
            this.tabPage1.Controls.Add(this.label6);
            this.tabPage1.Controls.Add(this.label5);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.txtWs);
            this.tabPage1.Controls.Add(this.txtWq);
            this.tabPage1.Controls.Add(this.button3);
            this.tabPage1.Controls.Add(this.button2);
            this.tabPage1.Controls.Add(this.button1);
            this.tabPage1.Controls.Add(this.txtP0);
            this.tabPage1.Controls.Add(this.txtMho);
            this.tabPage1.Controls.Add(this.txtRho);
            this.tabPage1.Controls.Add(this.txtLs);
            this.tabPage1.Controls.Add(this.txtLq);
            this.tabPage1.Controls.Add(this.txtLambda);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1176, 499);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "tabPage1";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // txtN
            // 
            this.txtN.BackColor = System.Drawing.Color.PeachPuff;
            this.txtN.Font = new System.Drawing.Font("Tahoma", 12F);
            this.txtN.Location = new System.Drawing.Point(510, 275);
            this.txtN.Name = "txtN";
            this.txtN.Size = new System.Drawing.Size(157, 32);
            this.txtN.TabIndex = 28;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.SlateGray;
            this.button4.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold);
            this.button4.Location = new System.Drawing.Point(545, 232);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(122, 32);
            this.button4.TabIndex = 27;
            this.button4.Text = "CalcPn";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold);
            this.label12.Location = new System.Drawing.Point(695, 187);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(36, 24);
            this.label12.TabIndex = 26;
            this.label12.Text = "Pn";
            // 
            // txtPn
            // 
            this.txtPn.BackColor = System.Drawing.Color.PeachPuff;
            this.txtPn.Font = new System.Drawing.Font("Tahoma", 12F);
            this.txtPn.Location = new System.Drawing.Point(510, 184);
            this.txtPn.Name = "txtPn";
            this.txtPn.Size = new System.Drawing.Size(157, 32);
            this.txtPn.TabIndex = 25;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold);
            this.label11.Location = new System.Drawing.Point(695, 58);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(36, 24);
            this.label11.TabIndex = 24;
            this.label11.Text = "P0";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold);
            this.label10.Location = new System.Drawing.Point(336, 432);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(44, 24);
            this.label10.TabIndex = 23;
            this.label10.Text = "Wq";
            this.label10.Click += new System.EventHandler(this.label10_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold);
            this.label9.Location = new System.Drawing.Point(346, 379);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(0, 24);
            this.label9.TabIndex = 22;
            this.label9.Click += new System.EventHandler(this.label9_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold);
            this.label8.Location = new System.Drawing.Point(346, 387);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(41, 24);
            this.label8.TabIndex = 21;
            this.label8.Text = "Ws";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold);
            this.label7.Location = new System.Drawing.Point(346, 116);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(54, 24);
            this.label7.TabIndex = 20;
            this.label7.Text = "mho";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold);
            this.label6.Location = new System.Drawing.Point(390, 171);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(44, 24);
            this.label6.TabIndex = 19;
            this.label6.Text = "rho";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold);
            this.label5.Location = new System.Drawing.Point(346, 275);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(0, 24);
            this.label5.TabIndex = 18;
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold);
            this.label4.Location = new System.Drawing.Point(362, 275);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(34, 24);
            this.label4.TabIndex = 17;
            this.label4.Text = "LS";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold);
            this.label3.Location = new System.Drawing.Point(346, 333);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(34, 24);
            this.label3.TabIndex = 16;
            this.label3.Text = "Lq";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold);
            this.label2.Location = new System.Drawing.Point(346, 46);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(72, 24);
            this.label2.TabIndex = 15;
            this.label2.Text = "lamda";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // txtWs
            // 
            this.txtWs.BackColor = System.Drawing.Color.PeachPuff;
            this.txtWs.Font = new System.Drawing.Font("Tahoma", 12F);
            this.txtWs.Location = new System.Drawing.Point(126, 379);
            this.txtWs.Name = "txtWs";
            this.txtWs.Size = new System.Drawing.Size(157, 32);
            this.txtWs.TabIndex = 13;
            // 
            // txtWq
            // 
            this.txtWq.BackColor = System.Drawing.Color.PeachPuff;
            this.txtWq.Font = new System.Drawing.Font("Tahoma", 12F);
            this.txtWq.Location = new System.Drawing.Point(126, 429);
            this.txtWq.Name = "txtWq";
            this.txtWq.Size = new System.Drawing.Size(157, 32);
            this.txtWq.TabIndex = 12;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.SlateGray;
            this.button3.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold);
            this.button3.Location = new System.Drawing.Point(545, 116);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(122, 32);
            this.button3.TabIndex = 11;
            this.button3.Text = "CalcP0";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.SlateGray;
            this.button2.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold);
            this.button2.Location = new System.Drawing.Point(126, 214);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(242, 32);
            this.button2.TabIndex = 10;
            this.button2.Text = "Calc Performance";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.SlateGray;
            this.button1.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold);
            this.button1.Location = new System.Drawing.Point(59, 163);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(122, 32);
            this.button1.TabIndex = 9;
            this.button1.Text = "CslcRho";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // txtP0
            // 
            this.txtP0.BackColor = System.Drawing.Color.PeachPuff;
            this.txtP0.Font = new System.Drawing.Font("Tahoma", 12F);
            this.txtP0.Location = new System.Drawing.Point(510, 55);
            this.txtP0.Name = "txtP0";
            this.txtP0.Size = new System.Drawing.Size(157, 32);
            this.txtP0.TabIndex = 8;
            this.txtP0.TextChanged += new System.EventHandler(this.txtP0_TextChanged);
            // 
            // txtMho
            // 
            this.txtMho.BackColor = System.Drawing.Color.PeachPuff;
            this.txtMho.Font = new System.Drawing.Font("Tahoma", 12F);
            this.txtMho.Location = new System.Drawing.Point(117, 108);
            this.txtMho.Name = "txtMho";
            this.txtMho.Size = new System.Drawing.Size(157, 32);
            this.txtMho.TabIndex = 7;
            // 
            // txtRho
            // 
            this.txtRho.BackColor = System.Drawing.Color.PeachPuff;
            this.txtRho.Font = new System.Drawing.Font("Tahoma", 12F);
            this.txtRho.Location = new System.Drawing.Point(187, 161);
            this.txtRho.Name = "txtRho";
            this.txtRho.Size = new System.Drawing.Size(157, 32);
            this.txtRho.TabIndex = 6;
            // 
            // txtLs
            // 
            this.txtLs.BackColor = System.Drawing.Color.PeachPuff;
            this.txtLs.Font = new System.Drawing.Font("Tahoma", 12F);
            this.txtLs.Location = new System.Drawing.Point(126, 275);
            this.txtLs.Name = "txtLs";
            this.txtLs.Size = new System.Drawing.Size(157, 32);
            this.txtLs.TabIndex = 5;
            // 
            // txtLq
            // 
            this.txtLq.BackColor = System.Drawing.Color.PeachPuff;
            this.txtLq.Font = new System.Drawing.Font("Tahoma", 12F);
            this.txtLq.Location = new System.Drawing.Point(126, 330);
            this.txtLq.Name = "txtLq";
            this.txtLq.Size = new System.Drawing.Size(157, 32);
            this.txtLq.TabIndex = 4;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.textn);
            this.tabPage2.Controls.Add(this.CalcPn);
            this.tabPage2.Controls.Add(this.lblMMSReultP0);
            this.tabPage2.Controls.Add(this.calcMMSP0);
            this.tabPage2.Controls.Add(this.txtMMSP0);
            this.tabPage2.Controls.Add(this.label13);
            this.tabPage2.Controls.Add(this.label17);
            this.tabPage2.Controls.Add(this.label16);
            this.tabPage2.Controls.Add(this.label15);
            this.tabPage2.Controls.Add(this.txtMMSServicesCount);
            this.tabPage2.Controls.Add(this.txtMMSmho);
            this.tabPage2.Controls.Add(this.txtMMSLambda);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1176, 499);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "tabPage2";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // lblMMSReultP0
            // 
            this.lblMMSReultP0.AutoSize = true;
            this.lblMMSReultP0.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold);
            this.lblMMSReultP0.Location = new System.Drawing.Point(39, 238);
            this.lblMMSReultP0.Name = "lblMMSReultP0";
            this.lblMMSReultP0.Size = new System.Drawing.Size(36, 24);
            this.lblMMSReultP0.TabIndex = 11;
            this.lblMMSReultP0.Text = "P0";
            // 
            // calcMMSP0
            // 
            this.calcMMSP0.BackColor = System.Drawing.Color.Silver;
            this.calcMMSP0.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Bold);
            this.calcMMSP0.Location = new System.Drawing.Point(69, 188);
            this.calcMMSP0.Name = "calcMMSP0";
            this.calcMMSP0.Size = new System.Drawing.Size(106, 37);
            this.calcMMSP0.TabIndex = 10;
            this.calcMMSP0.Text = "Calc P";
            this.calcMMSP0.UseVisualStyleBackColor = false;
            this.calcMMSP0.Click += new System.EventHandler(this.calcMMSP0_Click);
            // 
            // txtMMSP0
            // 
            this.txtMMSP0.BackColor = System.Drawing.Color.MistyRose;
            this.txtMMSP0.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtMMSP0.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold);
            this.txtMMSP0.Location = new System.Drawing.Point(58, 279);
            this.txtMMSP0.Name = "txtMMSP0";
            this.txtMMSP0.Size = new System.Drawing.Size(145, 32);
            this.txtMMSP0.TabIndex = 9;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold);
            this.label13.Location = new System.Drawing.Point(562, 46);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(25, 24);
            this.label13.TabIndex = 8;
            this.label13.Text = "N";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold);
            this.label17.Location = new System.Drawing.Point(216, 40);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(85, 24);
            this.label17.TabIndex = 7;
            this.label17.Text = "lambda";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);
            this.label16.Location = new System.Drawing.Point(209, 142);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(128, 21);
            this.label16.TabIndex = 6;
            this.label16.Text = "Service Count";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold);
            this.label15.Location = new System.Drawing.Point(216, 101);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(54, 24);
            this.label15.TabIndex = 5;
            this.label15.Text = "mho";
            // 
            // txtMMSServicesCount
            // 
            this.txtMMSServicesCount.BackColor = System.Drawing.Color.MistyRose;
            this.txtMMSServicesCount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtMMSServicesCount.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold);
            this.txtMMSServicesCount.Location = new System.Drawing.Point(58, 137);
            this.txtMMSServicesCount.Name = "txtMMSServicesCount";
            this.txtMMSServicesCount.Size = new System.Drawing.Size(145, 32);
            this.txtMMSServicesCount.TabIndex = 2;
            // 
            // txtMMSmho
            // 
            this.txtMMSmho.BackColor = System.Drawing.Color.MistyRose;
            this.txtMMSmho.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtMMSmho.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold);
            this.txtMMSmho.Location = new System.Drawing.Point(58, 93);
            this.txtMMSmho.Name = "txtMMSmho";
            this.txtMMSmho.Size = new System.Drawing.Size(145, 32);
            this.txtMMSmho.TabIndex = 1;
            // 
            // txtMMSLambda
            // 
            this.txtMMSLambda.BackColor = System.Drawing.Color.MistyRose;
            this.txtMMSLambda.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtMMSLambda.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold);
            this.txtMMSLambda.Location = new System.Drawing.Point(58, 38);
            this.txtMMSLambda.Name = "txtMMSLambda";
            this.txtMMSLambda.Size = new System.Drawing.Size(145, 32);
            this.txtMMSLambda.TabIndex = 0;
            // 
            // CalcPn
            // 
            this.CalcPn.BackColor = System.Drawing.Color.Silver;
            this.CalcPn.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Bold);
            this.CalcPn.Location = new System.Drawing.Point(455, 126);
            this.CalcPn.Name = "CalcPn";
            this.CalcPn.Size = new System.Drawing.Size(106, 37);
            this.CalcPn.TabIndex = 12;
            this.CalcPn.Text = "Calc Pn";
            this.CalcPn.UseVisualStyleBackColor = false;
            // 
            // textn
            // 
            this.textn.BackColor = System.Drawing.Color.MistyRose;
            this.textn.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textn.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold);
            this.textn.Location = new System.Drawing.Point(391, 44);
            this.textn.Name = "textn";
            this.textn.Size = new System.Drawing.Size(145, 32);
            this.textn.TabIndex = 13;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1180, 538);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox txtLambda;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox txtP0;
        private System.Windows.Forms.TextBox txtMho;
        private System.Windows.Forms.TextBox txtRho;
        private System.Windows.Forms.TextBox txtLs;
        private System.Windows.Forms.TextBox txtLq;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TextBox txtWs;
        private System.Windows.Forms.TextBox txtWq;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtPn;
        private System.Windows.Forms.TextBox txtN;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txtMMSServicesCount;
        private System.Windows.Forms.TextBox txtMMSmho;
        private System.Windows.Forms.TextBox txtMMSLambda;
        private System.Windows.Forms.TextBox txtMMSP0;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button calcMMSP0;
        private System.Windows.Forms.Label lblMMSReultP0;
        private System.Windows.Forms.TextBox textn;
        private System.Windows.Forms.Button CalcPn;
    }
}

