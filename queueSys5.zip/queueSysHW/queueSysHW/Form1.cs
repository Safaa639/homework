﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace queueSysHW
{
    public partial class Form1 : Form
    {
        double mhoMMS = -1;
        double lambdaMMS = -1;
        double rhoMMS = -1;
        double p0MMS = -1;
        private double rho = -1;
        public Form1()
        {
            InitializeComponent();
            SetDefulatProp();
            SetDefulatPropForMMS();
        }
        private void SetDefulatPropForMMS()
        {
            txtMMSP0.ReadOnly = true;
        }
        private void SetDefulatProp()
        {
            txtLs.ReadOnly = true;
            txtLq.ReadOnly = true;
            txtWs.ReadOnly = true;
            txtWq.ReadOnly = true;
            txtRho.ReadOnly = true;
            txtP0.ReadOnly = true;
            txtPn.ReadOnly = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                double lambda = double.Parse(txtLambda.Text);
                double mu = double.Parse(txtMho.Text);
                if (mu == 0)
                {

                    throw new DivideByZeroException("لا يمكن ان تكون ميو صفر");
                }
                if (mu <= lambda)
                {
                    throw new Exception("لا يمكن ان تكون متساوية القيم");
                }
                rho = lambda / mu;
                txtRho.Text = rho.ToString("F2");
             
              
            }
            catch (Exception ex)
            {
                if (ex is FormatException)
                    MessageBox.Show("تأكد من إدخال قيم صحيحة للمدخلات.");
                else if (ex is DivideByZeroException)
                {
                    txtMho.BackColor = Color.Red;
                    MessageBox.Show(ex.Message);
                }
                else
                {
                    MessageBox.Show(ex.Message);
                }
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                double lambda = double.Parse(txtLambda.Text);
                double mu = double.Parse(txtMho.Text);

                if (lambda >= mu)
                {
                    MessageBox.Show("النظام غير مستقر. تأكد من أن معدل الوصول أقل من معدل الخدمة.");
                    HighlightTextBox(txtLs, Color.Red);
                    return;
                }

                double rho = lambda / mu;

                double L = rho / (1 - rho);
                double Lq = Math.Pow(rho, 2) / (1 - rho);
                double W = 1 / (mu - lambda);
                double Wq = rho / (mu - lambda);

                txtLs.Text = L.ToString("F2");//F2 to show only two number after point 
                txtLq.Text = Lq.ToString("F2");
                txtWs.Text = W.ToString("F2");
                txtWq.Text = Wq.ToString("F2");

            }
            catch (FormatException)
            {
                MessageBox.Show("تأكد من إدخال قيم صحيحة للمدخلات.");
            }
        }
        private Color GetColorBasedOnValue(double value, double threshold)
        {
            if (value < threshold)
            {
                return Color.LightGreen;
            }
            else if (value < threshold * 2)
            {
                return Color.Orange;
            }
            else
            {
                return Color.Red;
            }
        }

        private void HighlightTextBox(TextBox textBox, Color color)
        {
            textBox.BackColor = color;
        }

        private void button3_Click(object sender, EventArgs e) //p0
        {
            if (rho == -1)
            {
                throw new Exception("the rho negative");
            }


            txtP0.Text = (1 - rho).ToString("F2");
        }
               
            
          
        

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtP0_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {
          
        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                if (rho  ==-1)
                {
                    throw new Exception("  أولاً يرجى حسابها");
                }

                int n;
                if (int.TryParse(txtN.Text, out n) && n >= 0)
                {
                    
                    double Pn = Math.Pow(rho, n) * (1 - rho);
                    txtPn.Text = Pn.ToString("F2");
                }
                else
                {
                    MessageBox.Show("تأكد من إدخال قيمة صحيحة لـ n.");
                }
            }
            catch (FormatException)
            {
                MessageBox.Show("تأكد من إدخال قيمة صحيحة للمدخلات.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("حدث خطأ: " + ex.Message);
            }
        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

        private void label14_Click(object sender, EventArgs e)
        {

        }

        private void calcMMSP0_Click(object sender, EventArgs e)
        {
            mhoMMS = Convert.ToDouble(txtMMSmho.Text);
            lambdaMMS = Convert.ToDouble(txtMMSLambda.Text);
            n = Convert.ToInt32(textn.Text);
            try
            {
                if (n >= 1 && n <= Math.Max(1, servicesCount - 1))
                { CalcPn(lambdaMMS, mhoMMS, servicesCount, n); }
                else if (n > = servicesCount)
                {
                    CalcPn(lambdaMMS, mhoMMS, servicesCount, n);
                }
                else
                {
                    throw new FormatException(" تاكد من الادخال");
                }
                Pn = Pn * 100;
                textn.Text = ("Pn =" + pn + "%");
            } catch (Exception ex) { if (ex is FormatException)
                    throw new Exception("make sure ");
            else if(ex is DivideByZeroException) { MessageBox.Show(ex.Message); }
                        }
           


                double rateOfServices = mhoMMS * servicesCount;

                if (rhoMMS >= 1)
                {
                    MessageBox.Show("النظام غير مستقر. تأكد من أن معدل الوصول أقل من إجمالي معدل الخدمة.");
                    return;
                }
                rhoMMS = lambdaMMS / rateOfServices;
                p0MMS = CalcP0(servicesCount, rhoMMS);
                p0MMS = p0MMS * 100;
                lblMMSReultP0.Text = ("P0 = " + p0MMS + "%");
                 txtMMSP0.Text = ("P0 = " + p0MMS + "%");
                string results = $"النظام فارغ (P0): {p0MMS:F4}\n"; //حساب كل الاحتمالات
          

            }
            
        }

        private void CalcPn(double lambdaMMS, double mhoMMS, object servicesCount, object n)
        {try
            {
                if(n !=0 && n <= servicesCount - 1)
                {
                    double nump = Math.Pow(lambdaMMS, n);
                    double denuminator = Fact(n) * Math.Pow(mhoMMS, n);
                    double firstSecation = nump / denuminator;
                    pn = firstSecation * (1 / result);
                    pn = Pn * 100;
                }else if (n >= servicesCount)
                {
                    double services = Math.Pow(lambdaMMS, n)/Math.Pow(servicesCount,n-servicesCount)*(Fact(servicesCount)*(Math.Pow(mhoMMS,n)));

                }
            }
            catch(Exception ex)
            {
                MessageBox.Show($"خطأ غير متوقع: {ex.Message}");


            }
        }

        private double CalcP0(int servicesCount, double rhoMMS)
        {
            double firstSecation = 0;
            for (int x = 0; x <= servicesCount - 1; x++)
            {
                firstSecation = firstSecation
                        + (Math.Pow(servicesCount * rhoMMS, x) / Fact(x));
            }
            double secoundSecation = (Math.Pow(servicesCount * rhoMMS, servicesCount)
                            / (Fact(servicesCount) * (1 - rhoMMS)));
            double result = firstSecation + secoundSecation;

            return 1 / result;
        }
        private static long Fact(int number)
        {
            long factResult = 1;
            for (int i = number; i > 1; i--)
            {
                factResult = factResult * i;
            }
            return factResult;
        }

        private void lblResults_Click(object sender, EventArgs e)
        {

        }
    }

}
    

